package com.earlystream.tradecompass.gui;

import com.earlystream.tradecompass.TradeCompassClient;
import com.earlystream.tradecompass.data.GroupedSearchResult;
import com.earlystream.tradecompass.data.MerchantRecord;
import com.earlystream.tradecompass.data.SearchResult;
import com.earlystream.tradecompass.data.TradeSearchIndex;
import com.earlystream.tradecompass.data.TradeOfferRecord;
import com.earlystream.tradecompass.util.TimeTextUtil;
import com.earlystream.tradecompass.util.WorldKeyUtil;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1646;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_3730;
import net.minecraft.class_3850;
import net.minecraft.class_3852;
import net.minecraft.class_3854;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_490;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

public class TradeCompassScreen extends class_437 {
    private static final int ROW_HEIGHT = 92;
    private static String lastSelectedMerchantKey = null;
    private static int lastSelectedTradeIndex = 0;
    private class_342 searchBox;
    private class_4185 clearAllButton;
    private long clearPendingUntil = 0;
    private final List<GroupedSearchResult> results = new ArrayList<>();
    private final Map<String, class_1309> mugshotEntities = new HashMap<>();
    private int scrollOffset;
    private int selectedIndex = -1;
    private int selectedTradeIndex = 0;
    private int detailsScrollOffset = 0;

    public TradeCompassScreen() {
        super(class_2561.method_43470(TradeCompassClient.modName()));
    }

    @Override
    protected void method_25426() {
        searchBox = new class_342(field_22793, 18, 24, Math.max(120, field_22789 - 220), 20, class_2561.method_43470("Search trades"));
        searchBox.method_1863(value -> refreshResults());
        method_37063(searchBox);
        method_37063(class_4185.method_46430(class_2561.method_43470("Clear Target"), button -> TradeCompassClient.clearSelected()).method_46434(field_22789 - 190, 24, 82, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Delete"), button -> deleteSelected()).method_46434(field_22789 - 102, 24, 42, 20).method_46431());
        clearAllButton = method_37063(class_4185.method_46430(class_2561.method_43470("Clear All"), button -> {
            long now = System.currentTimeMillis();
            if (now < clearPendingUntil) {
                clearPendingUntil = 0;
                clearAllButton.method_25355(class_2561.method_43470("Clear All"));
                clearAll();
            } else {
                clearPendingUntil = now + 3000;
                clearAllButton.method_25355(class_2561.method_43470("Sure?"));
            }
        }).method_46434(field_22789 - 54, 24, 36, 20).method_46431());
        method_48265(searchBox);
        refreshResults();
    }

    @Override
    public boolean method_73150() {
        return true;
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        if (clearPendingUntil > 0 && System.currentTimeMillis() > clearPendingUntil) {
            clearPendingUntil = 0;
            clearAllButton.method_25355(class_2561.method_43470("Clear All"));
        }
        graphics.method_25294(0, 0, field_22789, field_22790, 0xD0101010);
        graphics.method_25294(0, 0, field_22789, 47, 0x18FFFFFF);
        graphics.method_51439(field_22793, field_22785, 18, 10, 0xFFFFFFFF, false);
        super.method_25394(graphics, mouseX, mouseY, partialTick);
        graphics.method_25294(0, 47, field_22789, 48, 0x60FFFFFF);
        graphics.method_25294(0, field_22790 - 23, field_22789, field_22790 - 22, 0x40FFFFFF);
        renderRows(graphics, mouseX, mouseY);
        renderDetails(graphics);
        graphics.method_51433(field_22793, "Saved: " + TradeCompassClient.database().size() + " villagers  |  Results: " + results.size() + "  |  " + TradeCompassClient.loadedWorldKey(), 18, field_22790 - 16, 0xFF707070, false);
    }

    private void renderRows(class_332 graphics, int mouseX, int mouseY) {
        int top = 54;
        int bottom = field_22790 - 24;
        int listRight = listRight();
        if (results.isEmpty()) {
            String message = TradeCompassClient.database().size() == 0 ? "No saved villager trades for this world yet" : "No saved trades match this search";
            graphics.method_51433(field_22793, message, 24, top + 14, 0xFFFFFF, false);
            graphics.method_51433(field_22793, "Open a villager trade screen once, then reopen Find My Villager.", 24, top + 30, 0xA0A0A0, false);
            return;
        }
        int visibleRows = Math.max(1, (bottom - top) / ROW_HEIGHT);
        long now = System.currentTimeMillis();
        for (int row = 0; row < visibleRows; row++) {
            int resultIndex = row + scrollOffset;
            if (resultIndex >= results.size()) {
                return;
            }
            GroupedSearchResult result = results.get(resultIndex);
            int y = top + row * ROW_HEIGHT;
            boolean hovered = mouseX >= 14 && mouseX <= listRight && mouseY >= y && mouseY < y + ROW_HEIGHT - 4;
            int fill = resultIndex == selectedIndex ? 0x804A6FA5 : hovered ? 0x602A2F38 : 0x40202020;
            graphics.method_25294(14, y, listRight, y + ROW_HEIGHT - 4, fill);
            graphics.method_25294(14, y, 17, y + ROW_HEIGHT - 4, levelAccentColor(result.merchant().levelNumber()));
            graphics.method_25294(17, y + ROW_HEIGHT - 5, listRight, y + ROW_HEIGHT - 4, 0x25FFFFFF);
            renderRowText(graphics, result, y, now);
            renderAvatar(graphics, result.merchant(), 24, y + 10, 40);
        }
        if (results.size() > visibleRows) {
            int maxScroll = results.size() - visibleRows;
            int barHeight = bottom - top;
            int thumbHeight = Math.max(12, barHeight * visibleRows / results.size());
            int thumbY = top + (barHeight - thumbHeight) * scrollOffset / maxScroll;
            graphics.method_25294(listRight - 3, top, listRight - 1, bottom, 0x28FFFFFF);
            graphics.method_25294(listRight - 3, thumbY, listRight - 1, thumbY + thumbHeight, 0xA0909090);
        }
    }

    private void renderRowText(class_332 graphics, GroupedSearchResult result, int y, long now) {
        MerchantRecord merchant = result.merchant();
        int textX = 74;

        graphics.method_51433(field_22793, merchant.professionLevelText(), textX, y + 6, 0xFFB8D7FF, false);
        graphics.method_51433(field_22793, merchant.levelProgressText() + "  -  " + distanceText(result), textX, y + 19, 0xFF888888, false);

        int matchCount = result.matchingOffers().size();
        String matchText = matchCount <= 1
                ? matchCount + " matching trade" + (matchCount == 1 ? "" : "s")
                : "1 of " + matchCount + " matching trades";
        graphics.method_51433(field_22793, matchText, textX, y + 32, 0xFFAAAAAA, false);

        int dotX = textX + field_22793.method_1727(matchText) + 6;
        for (int i = 0; i < Math.min(matchCount, 12); i++) {
            graphics.method_25294(dotX, y + 34, dotX + 4, y + 39,
                    result.matchingOffers().get(i).inStock() ? 0xFF3D8A4A : 0xFF8A3D3D);
            dotX += 6;
        }

        graphics.method_25294(textX, y + 43, listRight() - 8, y + 44, 0x22FFFFFF);

        int tradeY = y + 48;
        if (matchCount > 0) {
            TradeOfferRecord offer = result.matchingOffers().get(0);
            int nameColor = offer.inStock() ? 0xFFBBEEBB : 0xFFEEBBBB;
            graphics.method_51433(field_22793, offer.displayOutputName(), textX + 4, tradeY, nameColor, false);
            graphics.method_51433(field_22793, offer.priceText(), textX + 4, tradeY + 11, 0xFF666666, false);
            if (matchCount > 1) {
                graphics.method_51433(field_22793, "+" + (matchCount - 1) + " more", textX + 4 + Math.max(95, field_22793.method_1727(offer.priceText()) + 12), tradeY + 11, 0xFF777777, false);
            }
        }

        graphics.method_51433(field_22793, merchant.coordinatesText() + "  -  " + TimeTextUtil.ago(merchant.lastScannedEpochMillis(), now), textX, y + 79, 0xFF555555, false);
    }

    private void renderDetails(class_332 graphics) {
        int left = listRight() + 10;
        if (left > field_22789 - 170) {
            return;
        }
        int right = field_22789 - 14;
        int top = 54;
        graphics.method_25294(left - 5, 48, left - 4, field_22790 - 23, 0x40FFFFFF);
        graphics.method_25294(left, top, right, field_22790 - 24, 0x40202020);
        GroupedSearchResult selected = selectedIndex >= 0 && selectedIndex < results.size() ? results.get(selectedIndex) : null;
        if (selected == null) {
            graphics.method_51433(field_22793, "Select a villager", left + 12, top + 20, 0xFFFFFFFF, false);
            graphics.method_51433(field_22793, "Click a row to see all of its trades here.", left + 12, top + 36, 0xFF808080, false);
            return;
        }
        MerchantRecord merchant = selected.merchant();
        long now = System.currentTimeMillis();
        graphics.method_25294(left, top, right, top + 100, 0x20FFFFFF);
        graphics.method_51433(field_22793, merchant.professionLevelText(), left + 70, top + 12, 0xFFFFFFFF, false);
        graphics.method_51433(field_22793, merchant.levelProgressText(), left + 70, top + 26, 0xFFD0D0D0, false);
        renderLevelProgressBar(graphics, merchant, left + 70, top + 40, Math.max(60, right - left - 86));
        graphics.method_51433(field_22793, merchant.status(now) + " - " + distanceText(selected), left + 70, top + 52, 0xFFB8D7FF, false);
        graphics.method_51433(field_22793, merchant.coordinatesText(), left + 12, top + 66, 0xFFC8C8C8, false);
        graphics.method_51433(field_22793, "Last checked: " + TimeTextUtil.ago(merchant.lastScannedEpochMillis(), now), left + 12, top + 80, 0xFFA8A8A8, false);
        renderAvatar(graphics, merchant, left + 12, top + 12, 48);
        graphics.method_25294(left + 8, top + 100, right - 8, top + 101, 0x50FFFFFF);
        int inStockCount = 0;
        for (TradeOfferRecord t : merchant.offers()) {
            if (t.inStock()) {
                inStockCount++;
            }
        }
        int outCount = merchant.offers().size() - inStockCount;
        String tradesLabel = merchant.offers().size() + " trades";
        if (outCount > 0) {
            tradesLabel += "  -  " + inStockCount + " in  -  " + outCount + " out";
        } else {
            tradesLabel += "  -  all in stock";
        }
        graphics.method_51433(field_22793, tradesLabel, left + 12, top + 106, 0xFF909090, false);
        int listTop = top + 122;
        int listBottom = field_22790 - 24;
        int maxVisible = Math.max(1, (listBottom - listTop) / 36);
        int totalTrades = merchant.offers().size();
        int maxScroll = Math.max(0, totalTrades - maxVisible);
        detailsScrollOffset = Math.max(0, Math.min(maxScroll, detailsScrollOffset));
        graphics.method_44379(left, listTop, right, listBottom);
        try {
            int y = listTop;
            for (int i = detailsScrollOffset; i < totalTrades && y < listBottom + 34; i++) {
                TradeOfferRecord offer = merchant.offers().get(i);
                int nameColor = offer.inStock() ? 0xFFFFFFFF : 0xFFCC9999;
                int statusColor = offer.inStock() ? 0xFF6DB86D : 0xFF997070;
                int stockBar = offer.inStock() ? 0xFF3A8A4A : 0xFF8A3A3A;
                String status = offer.inStock()
                        ? offer.remainingUses() + " / " + offer.maxUses() + " uses left"
                        : "Sold out";
                int cardFill = (i == selectedTradeIndex) ? 0x40FFFFFF : 0x15FFFFFF;
                graphics.method_25294(left + 12, y, right - 8, y + 34, cardFill);
                graphics.method_25294(left + 12, y, left + 14, y + 34, stockBar);
                graphics.method_51433(field_22793, offer.displayOutputName(), left + 18, y + 2, nameColor, false);
                graphics.method_51433(field_22793, offer.priceText(), left + 18, y + 13, 0xFF909090, false);
                graphics.method_51433(field_22793, status, left + 18, y + 24, statusColor, false);
                y += 36;
            }
        } finally {
            graphics.method_44380();
        }
        if (maxScroll > 0) {
            int barHeight = listBottom - listTop;
            int thumbHeight = Math.max(10, barHeight * maxVisible / totalTrades);
            int thumbY = listTop + (barHeight - thumbHeight) * detailsScrollOffset / maxScroll;
            graphics.method_25294(right - 4, listTop, right - 2, listBottom, 0x30FFFFFF);
            graphics.method_25294(right - 4, thumbY, right - 2, thumbY + thumbHeight, 0xA0AAAAAA);
        }
    }

    private void renderAvatar(class_332 graphics, MerchantRecord merchant, int x, int y, int size) {
        graphics.method_25294(x, y, x + size, y + size, 0xFF171B1F);
        graphics.method_25294(x + 1, y + 1, x + size - 1, y + size - 1, 0xFF2B332E);
        class_1309 mugshot = mugshotEntity(merchant);
        if (mugshot != null) {
            graphics.method_44379(x + 2, y + 2, x + size - 2, y + size - 2);
            try {
                int renderScale = Math.max(58, Math.round(size * 1.42F));
                int verticalNudge = 4;
                class_490.method_2486(
                        graphics,
                        x - size,
                        y - size - verticalNudge,
                        x + size * 2,
                        y + size * 2 - verticalNudge,
                        renderScale,
                        0.55F,
                        x + size / 2.0F,
                        y + size / 2.0F,
                        mugshot
                );
            } catch (Exception ignored) {
            } finally {
                graphics.method_44380();
            }
            graphics.method_73198(x, y, size, size, 0x8068A36F);
            return;
        }
        int robeColor = professionColor(merchant.profession());
        graphics.method_25294(x, y, x + size, y + size, 0xFF2D241B);
        graphics.method_25294(x + 4, y + 4, x + size - 4, y + size - 4, 0xFFC9956B);
        graphics.method_25294(x + 6, y + size - 12, x + size - 6, y + size - 4, robeColor);
        graphics.method_25294(x + 10, y + 14, x + 14, y + 18, 0xFF2A1A12);
        graphics.method_25294(x + size - 14, y + 14, x + size - 10, y + 18, 0xFF2A1A12);
        graphics.method_25294(x + size / 2 - 3, y + 18, x + size / 2 + 3, y + 26, 0xFF8F5F3E);
        String initial = merchant.profession().isBlank() ? "?" : merchant.profession().substring(0, 1);
        graphics.method_51433(field_22793, initial, x + size / 2 - 3, y + size - 12, 0xFFFFFFFF, false);
    }

    private class_1309 mugshotEntity(MerchantRecord merchant) {
        class_310 client = class_310.method_1551();
        if (client.field_1687 == null) {
            return null;
        }
        String cacheKey = merchant.entityTypeId() + "|" + merchant.professionId() + "|" + merchant.levelNumber() + "|" + merchant.profession();
        return mugshotEntities.computeIfAbsent(cacheKey, key -> createMugshotEntity(client, merchant));
    }

    private class_1309 createMugshotEntity(class_310 client, MerchantRecord merchant) {
        if ("minecraft:wandering_trader".equals(merchant.entityTypeId()) || "Wandering Trader".equalsIgnoreCase(merchant.profession())) {
            return class_1299.field_17713.method_5883(client.field_1687, class_3730.field_52444);
        }
        class_1646 villager = class_1299.field_6077.method_5883(client.field_1687, class_3730.field_52444);
        if (villager == null) {
            return null;
        }
        class_6880<class_3854> villagerType = class_7923.field_41194.method_10223(class_2960.method_60656("plains"))
                .or(() -> class_7923.field_41194.method_60385())
                .orElse(null);
        String professionId = merchant.professionId().isBlank() ? "minecraft:none" : merchant.professionId();
        class_6880<class_3852> profession = class_7923.field_41195.method_10223(class_2960.method_60654(professionId))
                .or(() -> class_7923.field_41195.method_10223(class_2960.method_60656("none")))
                .or(() -> class_7923.field_41195.method_60385())
                .orElse(null);
        int level = merchant.levelNumber() > 0 ? merchant.levelNumber() : levelNumberFromText(merchant.level());
        if (villagerType != null && profession != null) {
            villager.method_7195(new class_3850(villagerType, profession, Math.max(1, Math.min(5, level))));
        }
        villager.method_36456(180.0F);
        villager.method_5636(180.0F);
        villager.method_36457(0.0F);
        return villager;
    }

    private int levelNumberFromText(String level) {
        if ("Apprentice".equalsIgnoreCase(level)) {
            return 2;
        }
        if ("Journeyman".equalsIgnoreCase(level)) {
            return 3;
        }
        if ("Expert".equalsIgnoreCase(level)) {
            return 4;
        }
        if ("Master".equalsIgnoreCase(level)) {
            return 5;
        }
        return 1;
    }

    private int levelAccentColor(int level) {
        return switch (level) {
            case 2 -> 0xFF4E9E4E;
            case 3 -> 0xFF4E7EC0;
            case 4 -> 0xFFC07830;
            case 5 -> 0xFFC0A030;
            default -> 0xFF706050;
        };
    }

    private int professionColor(String profession) {
        int hash = profession == null ? 0 : profession.hashCode();
        int r = 80 + Math.abs(hash & 0x5F);
        int g = 80 + Math.abs((hash >> 8) & 0x5F);
        int b = 80 + Math.abs((hash >> 16) & 0x5F);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private int listRight() {
        return Math.min(field_22789 - 190, Math.max(360, (int) (field_22789 * 0.62F)));
    }

    private void renderLevelProgressBar(class_332 graphics, MerchantRecord merchant, int x, int y, int width) {
        int percent = merchant.levelProgressPercent();
        if (percent < 0 || percent >= 100 || merchant.levelNumber() >= 5) {
            return;
        }
        graphics.method_25294(x, y, x + width, y + 6, 0xFF252A30);
        graphics.method_25294(x, y, x + Math.max(1, width * percent / 100), y + 6, 0xFF6EA86E);
    }

    private String tradeSummary(TradeOfferRecord offer) {
        String output = offer.output().count() > 1
                ? offer.output().count() + "x " + offer.displayOutputName()
                : offer.displayOutputName();
        String stock = offer.inStock() ? "" : " [OUT OF STOCK]";
        return offer.priceText() + " -> " + output + stock;
    }

    private String distanceText(GroupedSearchResult result) {
        if (result.merchant().unknownPosition()) {
            return "Unknown position";
        }
        return result.distance() < 0 ? "Different dimension" : Math.round(result.distance()) + "m away";
    }

    private void refreshResults() {
        class_310 client = class_310.method_1551();
        String dimension = WorldKeyUtil.currentDimension(client);
        double x = client.field_1724 == null ? 0.0D : client.field_1724.method_23317();
        double y = client.field_1724 == null ? 0.0D : client.field_1724.method_23318();
        double z = client.field_1724 == null ? 0.0D : client.field_1724.method_23321();
        results.clear();
        results.addAll(TradeSearchIndex.searchGrouped(TradeCompassClient.database(), searchBox == null ? "" : searchBox.method_1882(), dimension, x, y, z));
        scrollOffset = Math.min(scrollOffset, Math.max(0, results.size() - 1));
        selectedIndex = results.isEmpty() ? -1 : 0;
        selectedTradeIndex = 0;
        detailsScrollOffset = 0;
        if (lastSelectedMerchantKey != null) {
            for (int i = 0; i < results.size(); i++) {
                if (results.get(i).merchant().merchantKey().equals(lastSelectedMerchantKey)) {
                    selectedIndex = i;
                    selectedTradeIndex = lastSelectedTradeIndex;
                    int visibleRows = Math.max(1, (field_22790 - 78) / ROW_HEIGHT);
                    scrollOffset = Math.max(0, selectedIndex - visibleRows / 2);
                    detailsScrollOffset = Math.max(0, selectedTradeIndex - 2);
                    break;
                }
            }
        }
        selectCurrentResult();
        targetSelectedTrade();
    }

    private void selectCurrentResult() {
        if (selectedIndex < 0 || selectedIndex >= results.size()) {
            return;
        }
        GroupedSearchResult result = results.get(selectedIndex);
        lastSelectedMerchantKey = result.merchant().merchantKey();
        List<TradeOfferRecord> offers = result.merchant().offers();
        if (selectedTradeIndex >= offers.size()) {
            selectedTradeIndex = 0;
        }
        lastSelectedTradeIndex = selectedTradeIndex;
    }

    private void targetSelectedTrade() {
        if (selectedIndex < 0 || selectedIndex >= results.size()) {
            return;
        }
        GroupedSearchResult result = results.get(selectedIndex);
        List<TradeOfferRecord> offers = result.merchant().offers();
        if (offers.isEmpty()) {
            return;
        }
        TradeOfferRecord offer = selectedTradeIndex < offers.size() ? offers.get(selectedTradeIndex) : offers.get(0);
        TradeCompassClient.select(new SearchResult(result.merchant(), offer, result.distance()));
    }

    private void deleteSelected() {
        if (selectedIndex < 0 || selectedIndex >= results.size()) {
            return;
        }
        TradeCompassClient.database().delete(results.get(selectedIndex).merchant().merchantKey());
        TradeCompassClient.clearSelected();
        TradeCompassClient.save();
        refreshResults();
    }

    private void clearAll() {
        TradeCompassClient.database().clear();
        TradeCompassClient.clearSelected();
        TradeCompassClient.save();
        refreshResults();
    }

    @Override
    public boolean method_25402(class_11909 event, boolean doubleClick) {
        if (super.method_25402(event, doubleClick)) {
            return true;
        }
        int left = listRight() + 10;
        int right = field_22789 - 14;
        int listTop = 54 + 122;
        int listBottom = field_22790 - 24;
        if (event.comp_4798() > left && event.comp_4798() < right && event.comp_4799() >= listTop && event.comp_4799() < listBottom
                && selectedIndex >= 0 && selectedIndex < results.size()) {
            int tradeIndex = detailsScrollOffset + ((int) event.comp_4799() - listTop) / 36;
            MerchantRecord merchant = results.get(selectedIndex).merchant();
            if (tradeIndex >= 0 && tradeIndex < merchant.offers().size()) {
                selectedTradeIndex = tradeIndex;
                lastSelectedTradeIndex = tradeIndex;
                lastSelectedMerchantKey = merchant.merchantKey();
                TradeOfferRecord offer = merchant.offers().get(tradeIndex);
                TradeCompassClient.select(new SearchResult(merchant, offer, results.get(selectedIndex).distance()));
                return true;
            }
        }
        int index = event.comp_4798() <= listRight() ? rowIndex(event.comp_4799()) : -1;
        if (index >= 0 && index < results.size()) {
            if (index != selectedIndex) {
                selectedTradeIndex = 0;
                detailsScrollOffset = 0;
            }
            selectedIndex = index;
            selectCurrentResult();
            targetSelectedTrade();
            return true;
        }
        return false;
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int dir = (int) Math.signum(verticalAmount);
        if (mouseX > listRight() && selectedIndex >= 0 && selectedIndex < results.size()) {
            int totalTrades = results.get(selectedIndex).merchant().offers().size();
            int maxVisible = Math.max(1, (field_22790 - 24 - (54 + 122)) / 36);
            detailsScrollOffset = Math.max(0, Math.min(Math.max(0, totalTrades - maxVisible), detailsScrollOffset - dir));
        } else {
            scroll(-dir * 3);
        }
        return true;
    }

    @Override
    public boolean method_25404(class_11908 event) {
        int visibleRows = Math.max(1, (field_22790 - 78) / ROW_HEIGHT);
        int keyCode = event.comp_4795();
        if (keyCode == GLFW.GLFW_KEY_UP) {
            scroll(-1);
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_DOWN) {
            scroll(1);
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_PAGE_UP) {
            scroll(-visibleRows);
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_PAGE_DOWN) {
            scroll(visibleRows);
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_HOME) {
            scrollOffset = 0;
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_END) {
            scrollOffset = Math.max(0, results.size() - Math.max(1, visibleRows));
            return true;
        }
        return super.method_25404(event);
    }

    private void scroll(int delta) {
        int max = Math.max(0, results.size() - Math.max(1, (field_22790 - 78) / ROW_HEIGHT));
        scrollOffset = Math.max(0, Math.min(max, scrollOffset + delta));
    }

    private int rowIndex(double mouseY) {
        int top = 54;
        if (mouseY < top || mouseY > field_22790 - 24) {
            return -1;
        }
        return ((int) mouseY - top) / ROW_HEIGHT + scrollOffset;
    }
}
