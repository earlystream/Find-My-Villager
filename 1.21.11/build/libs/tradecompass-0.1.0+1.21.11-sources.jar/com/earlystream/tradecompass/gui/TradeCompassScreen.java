package com.earlystream.tradecompass.gui;

import com.earlystream.tradecompass.TradeCompassClient;
import com.earlystream.tradecompass.data.GroupedSearchResult;
import com.earlystream.tradecompass.data.MerchantRecord;
import com.earlystream.tradecompass.data.SearchResult;
import com.earlystream.tradecompass.data.TradeSearchIndex;
import com.earlystream.tradecompass.data.TradeOfferRecord;
import com.earlystream.tradecompass.util.TimeTextUtil;
import com.earlystream.tradecompass.util.WorldKeyUtil;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_11909;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1646;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_3730;
import net.minecraft.class_3850;
import net.minecraft.class_3852;
import net.minecraft.class_3854;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_490;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

public class TradeCompassScreen extends class_437 {
    private static final int ROW_HEIGHT = 92;
    private class_342 searchBox;
    private final List<GroupedSearchResult> results = new ArrayList<>();
    private final Map<String, class_1309> mugshotEntities = new HashMap<>();
    private int scrollOffset;
    private int selectedIndex = -1;

    public TradeCompassScreen() {
        super(class_2561.method_43470(TradeCompassClient.modName()));
    }

    @Override
    protected void method_25426() {
        searchBox = new class_342(field_22793, 18, 24, Math.max(120, field_22789 - 220), 20, class_2561.method_43470("Search trades"));
        searchBox.method_1863(value -> refreshResults());
        method_37063(searchBox);
        method_37063(class_4185.method_46430(class_2561.method_43470("Clear Target"), button -> TradeCompassClient.clearSelected()).method_46434(field_22789 - 190, 24, 82, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Delete"), button -> deleteSelected()).method_46434(field_22789 - 102, 24, 42, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Clear All"), button -> clearAll()).method_46434(field_22789 - 54, 24, 36, 20).method_46431());
        method_48265(searchBox);
        refreshResults();
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        graphics.method_25294(0, 0, field_22789, field_22790, 0xD0101010);
        graphics.method_51439(field_22793, field_22785, 18, 10, 0xFFFFFF, false);
        super.method_25394(graphics, mouseX, mouseY, partialTick);
        renderRows(graphics, mouseX, mouseY);
        renderDetails(graphics);
        graphics.method_51433(field_22793, "Saved villagers: " + TradeCompassClient.database().size() + " | Results: " + results.size() + " | World: " + TradeCompassClient.loadedWorldKey(), 18, field_22790 - 16, 0xA0A0A0, false);
    }

    private void renderRows(class_332 graphics, int mouseX, int mouseY) {
        int top = 54;
        int bottom = field_22790 - 24;
        int listRight = listRight();
        if (results.isEmpty()) {
            String message = TradeCompassClient.database().size() == 0 ? "No saved villager trades for this world yet" : "No saved trades match this search";
            graphics.method_51433(field_22793, message, 24, top + 14, 0xFFFFFF, false);
            graphics.method_51433(field_22793, "Open a villager trade screen once, then reopen Trade Compass.", 24, top + 30, 0xA0A0A0, false);
            return;
        }
        int visibleRows = Math.max(1, (bottom - top) / ROW_HEIGHT);
        long now = System.currentTimeMillis();
        for (int row = 0; row < visibleRows; row++) {
            int resultIndex = row + scrollOffset;
            if (resultIndex >= results.size()) {
                return;
            }
            GroupedSearchResult result = results.get(resultIndex);
            int y = top + row * ROW_HEIGHT;
            boolean hovered = mouseX >= 14 && mouseX <= listRight && mouseY >= y && mouseY < y + ROW_HEIGHT - 4;
            int fill = resultIndex == selectedIndex ? 0x804A6FA5 : hovered ? 0x602A2F38 : 0x40202020;
            graphics.method_25294(14, y, listRight, y + ROW_HEIGHT - 4, fill);
            renderRowText(graphics, result, y, now);
            renderAvatar(graphics, result.merchant(), 24, y + 10, 40);
        }
    }

    private void renderRowText(class_332 graphics, GroupedSearchResult result, int y, long now) {
        MerchantRecord merchant = result.merchant();
        int textX = 74;
        String footer = merchant.coordinatesText() + " - checked " + TimeTextUtil.ago(merchant.lastScannedEpochMillis(), now);
        graphics.method_51433(field_22793, merchant.professionLevelText(), textX, y + 6, 0xB8D7FF, false);
        graphics.method_51433(field_22793, merchant.levelProgressText() + " - " + distanceText(result), textX, y + 19, 0xD0D0D0, false);
        graphics.method_51433(field_22793, result.matchingOffers().size() + " matching trade" + (result.matchingOffers().size() == 1 ? "" : "s"), textX, y + 32, 0xFFFFFF, false);
        int tradeY = y + 48;
        int shownTrades = Math.min(1, result.matchingOffers().size());
        for (int i = 0; i < shownTrades; i++) {
            TradeOfferRecord offer = result.matchingOffers().get(i);
            int color = offer.inStock() ? 0xD8FFD8 : 0xFFB0A0;
            graphics.method_51433(field_22793, tradeSummary(offer), textX + 8, tradeY, color, false);
            graphics.method_51433(field_22793, offer.stockText(), textX + 8, tradeY + 11, 0xA8A8A8, false);
        }
        if (result.matchingOffers().size() > shownTrades) {
            graphics.method_51433(field_22793, "+" + (result.matchingOffers().size() - shownTrades) + " more", textX + 120, tradeY + 11, 0xA0A0A0, false);
        }
        graphics.method_51433(field_22793, footer, textX, y + 79, 0x909090, false);
    }

    private void renderDetails(class_332 graphics) {
        int left = listRight() + 10;
        if (left > field_22789 - 170) {
            return;
        }
        int right = field_22789 - 14;
        int top = 54;
        graphics.method_25294(left, top, right, field_22790 - 24, 0x50202020);
        GroupedSearchResult selected = selectedIndex >= 0 && selectedIndex < results.size() ? results.get(selectedIndex) : null;
        if (selected == null) {
            graphics.method_51433(field_22793, "Select a villager trade", left + 12, top + 12, 0xFFFFFF, false);
            graphics.method_51433(field_22793, "The target panel shows every trade saved from the last check.", left + 12, top + 28, 0xA0A0A0, false);
            return;
        }
        MerchantRecord merchant = selected.merchant();
        long now = System.currentTimeMillis();
        graphics.method_51433(field_22793, merchant.professionLevelText(), left + 70, top + 12, 0xFFFFFF, false);
        graphics.method_51433(field_22793, merchant.levelProgressText(), left + 70, top + 26, 0xD0D0D0, false);
        renderLevelProgressBar(graphics, merchant, left + 70, top + 40, Math.max(60, right - left - 86));
        graphics.method_51433(field_22793, merchant.status(now) + " - " + distanceText(selected), left + 70, top + 52, 0xB8D7FF, false);
        graphics.method_51433(field_22793, merchant.coordinatesText(), left + 12, top + 66, 0xC8C8C8, false);
        graphics.method_51433(field_22793, "Last checked: " + TimeTextUtil.ago(merchant.lastScannedEpochMillis(), now), left + 12, top + 80, 0xA8A8A8, false);
        renderAvatar(graphics, merchant, left + 12, top + 12, 48);
        graphics.method_51433(field_22793, "Trades last checked", left + 12, top + 106, 0xFFFFFF, false);
        int y = top + 122;
        int maxTrades = Math.max(1, (field_22790 - y - 30) / 52);
        for (int i = 0; i < merchant.offers().size() && i < maxTrades; i++) {
            TradeOfferRecord offer = merchant.offers().get(i);
            int color = offer.inStock() ? 0xCFE8CF : 0xB87878;
            graphics.method_51433(field_22793, offer.displayOutputName(), left + 18, y, 0xFFFFFF, false);
            graphics.method_51433(field_22793, offer.priceText(), left + 18, y + 10, 0xD0D0D0, false);
            graphics.method_51433(field_22793, offer.stockText(), left + 18, y + 20, color, false);
            graphics.method_51433(field_22793, offer.availableOutputText(), left + 18, y + 30, 0xB8B8B8, false);
            graphics.method_51433(field_22793, offer.restockText(), left + 18, y + 40, color, false);
            y += 52;
        }
        if (merchant.offers().size() > maxTrades) {
            graphics.method_51433(field_22793, "+" + (merchant.offers().size() - maxTrades) + " more trades", left + 18, y, 0xA0A0A0, false);
        }
    }

    private void renderAvatar(class_332 graphics, MerchantRecord merchant, int x, int y, int size) {
        graphics.method_25294(x, y, x + size, y + size, 0xFF171B1F);
        graphics.method_25294(x + 1, y + 1, x + size - 1, y + size - 1, 0xFF2B332E);
        class_1309 mugshot = mugshotEntity(merchant);
        if (mugshot != null) {
            graphics.method_44379(x + 2, y + 2, x + size - 2, y + size - 2);
            try {
                int renderScale = Math.max(58, Math.round(size * 1.42F));
                int verticalNudge = 4;
                class_490.method_2486(
                        graphics,
                        x - size,
                        y - size - verticalNudge,
                        x + size * 2,
                        y + size * 2 - verticalNudge,
                        renderScale,
                        0.55F,
                        x + size / 2.0F,
                        y + size / 2.0F,
                        mugshot
                );
            } catch (Exception ignored) {
            } finally {
                graphics.method_44380();
            }
            graphics.method_73198(x, y, size, size, 0x8068A36F);
            return;
        }
        int robeColor = professionColor(merchant.profession());
        graphics.method_25294(x, y, x + size, y + size, 0xFF2D241B);
        graphics.method_25294(x + 4, y + 4, x + size - 4, y + size - 4, 0xFFC9956B);
        graphics.method_25294(x + 6, y + size - 12, x + size - 6, y + size - 4, robeColor);
        graphics.method_25294(x + 10, y + 14, x + 14, y + 18, 0xFF2A1A12);
        graphics.method_25294(x + size - 14, y + 14, x + size - 10, y + 18, 0xFF2A1A12);
        graphics.method_25294(x + size / 2 - 3, y + 18, x + size / 2 + 3, y + 26, 0xFF8F5F3E);
        String initial = merchant.profession().isBlank() ? "?" : merchant.profession().substring(0, 1);
        graphics.method_51433(field_22793, initial, x + size / 2 - 3, y + size - 12, 0xFFFFFFFF, false);
    }

    private class_1309 mugshotEntity(MerchantRecord merchant) {
        class_310 client = class_310.method_1551();
        if (client.field_1687 == null) {
            return null;
        }
        String cacheKey = merchant.entityTypeId() + "|" + merchant.professionId() + "|" + merchant.levelNumber() + "|" + merchant.profession();
        return mugshotEntities.computeIfAbsent(cacheKey, key -> createMugshotEntity(client, merchant));
    }

    private class_1309 createMugshotEntity(class_310 client, MerchantRecord merchant) {
        if ("minecraft:wandering_trader".equals(merchant.entityTypeId()) || "Wandering Trader".equalsIgnoreCase(merchant.profession())) {
            return class_1299.field_17713.method_5883(client.field_1687, class_3730.field_52444);
        }
        class_1646 villager = class_1299.field_6077.method_5883(client.field_1687, class_3730.field_52444);
        if (villager == null) {
            return null;
        }
        class_6880<class_3854> villagerType = class_7923.field_41194.method_10223(class_2960.method_60656("plains"))
                .or(() -> class_7923.field_41194.method_60385())
                .orElse(null);
        String professionId = merchant.professionId().isBlank() ? "minecraft:none" : merchant.professionId();
        class_6880<class_3852> profession = class_7923.field_41195.method_10223(class_2960.method_60654(professionId))
                .or(() -> class_7923.field_41195.method_10223(class_2960.method_60656("none")))
                .or(() -> class_7923.field_41195.method_60385())
                .orElse(null);
        int level = merchant.levelNumber() > 0 ? merchant.levelNumber() : levelNumberFromText(merchant.level());
        if (villagerType != null && profession != null) {
            villager.method_7195(new class_3850(villagerType, profession, Math.max(1, Math.min(5, level))));
        }
        villager.method_36456(180.0F);
        villager.method_5636(180.0F);
        villager.method_36457(0.0F);
        return villager;
    }

    private int levelNumberFromText(String level) {
        if ("Apprentice".equalsIgnoreCase(level)) {
            return 2;
        }
        if ("Journeyman".equalsIgnoreCase(level)) {
            return 3;
        }
        if ("Expert".equalsIgnoreCase(level)) {
            return 4;
        }
        if ("Master".equalsIgnoreCase(level)) {
            return 5;
        }
        return 1;
    }

    private int professionColor(String profession) {
        int hash = profession == null ? 0 : profession.hashCode();
        int r = 80 + Math.abs(hash & 0x5F);
        int g = 80 + Math.abs((hash >> 8) & 0x5F);
        int b = 80 + Math.abs((hash >> 16) & 0x5F);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private int listRight() {
        return Math.min(field_22789 - 190, Math.max(360, (int) (field_22789 * 0.62F)));
    }

    private void renderLevelProgressBar(class_332 graphics, MerchantRecord merchant, int x, int y, int width) {
        int percent = merchant.levelProgressPercent();
        if (percent < 0 || percent >= 100 || merchant.levelNumber() >= 5) {
            return;
        }
        graphics.method_25294(x, y, x + width, y + 6, 0xFF252A30);
        graphics.method_25294(x, y, x + Math.max(1, width * percent / 100), y + 6, 0xFF6EA86E);
    }

    private String tradeSummary(TradeOfferRecord offer) {
        String output = offer.output().count() > 1
                ? offer.output().count() + "x " + offer.displayOutputName()
                : offer.displayOutputName();
        String stock = offer.inStock() ? "" : " [OUT OF STOCK]";
        return offer.priceText() + " -> " + output + stock;
    }

    private String distanceText(GroupedSearchResult result) {
        if (result.merchant().unknownPosition()) {
            return "Unknown position";
        }
        return result.distance() < 0 ? "Different dimension" : Math.round(result.distance()) + "m away";
    }

    private void refreshResults() {
        class_310 client = class_310.method_1551();
        String dimension = WorldKeyUtil.currentDimension(client);
        double x = client.field_1724 == null ? 0.0D : client.field_1724.method_23317();
        double y = client.field_1724 == null ? 0.0D : client.field_1724.method_23318();
        double z = client.field_1724 == null ? 0.0D : client.field_1724.method_23321();
        results.clear();
        results.addAll(TradeSearchIndex.searchGrouped(TradeCompassClient.database(), searchBox == null ? "" : searchBox.method_1882(), dimension, x, y, z));
        scrollOffset = Math.min(scrollOffset, Math.max(0, results.size() - 1));
        selectedIndex = results.isEmpty() ? -1 : 0;
        selectCurrentResult();
    }

    private void selectCurrentResult() {
        if (selectedIndex < 0 || selectedIndex >= results.size()) {
            return;
        }
        GroupedSearchResult result = results.get(selectedIndex);
        TradeOfferRecord primaryOffer = result.primaryOffer();
        if (primaryOffer != null) {
            TradeCompassClient.select(new SearchResult(result.merchant(), primaryOffer, result.distance()));
        }
    }

    private void deleteSelected() {
        if (selectedIndex < 0 || selectedIndex >= results.size()) {
            return;
        }
        TradeCompassClient.database().delete(results.get(selectedIndex).merchant().merchantKey());
        TradeCompassClient.clearSelected();
        TradeCompassClient.save();
        refreshResults();
    }

    private void clearAll() {
        TradeCompassClient.database().clear();
        TradeCompassClient.clearSelected();
        TradeCompassClient.save();
        refreshResults();
    }

    @Override
    public boolean method_25402(class_11909 event, boolean doubleClick) {
        if (super.method_25402(event, doubleClick)) {
            return true;
        }
        int index = event.comp_4798() <= listRight() ? rowIndex(event.comp_4799()) : -1;
        if (index >= 0 && index < results.size()) {
            selectedIndex = index;
            selectCurrentResult();
            return true;
        }
        return false;
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int max = Math.max(0, results.size() - Math.max(1, (field_22790 - 78) / ROW_HEIGHT));
        scrollOffset = Math.max(0, Math.min(max, scrollOffset - (int) Math.signum(verticalAmount)));
        return true;
    }

    private int rowIndex(double mouseY) {
        int top = 54;
        if (mouseY < top || mouseY > field_22790 - 24) {
            return -1;
        }
        return ((int) mouseY - top) / ROW_HEIGHT + scrollOffset;
    }
}
