package com.earlystream.tradecompass.capture;

import com.earlystream.tradecompass.config.TradeCompassConfig;
import com.earlystream.tradecompass.util.MerchantTextUtil;
import com.earlystream.tradecompass.util.WorldKeyUtil;
import net.minecraft.class_1297;
import net.minecraft.class_3988;

public final class MerchantInteractionTracker {
    private static PendingMerchantInteraction pending;

    private MerchantInteractionTracker() {
    }

    public static void remember(class_1297 entity) {
        if (!(entity instanceof class_3988)) {
            return;
        }
        pending = new PendingMerchantInteraction(
                entity.method_5667().toString(),
                MerchantTextUtil.entityTypeId(entity),
                MerchantTextUtil.entityTypeName(entity),
                MerchantTextUtil.professionId(entity),
                MerchantTextUtil.professionName(entity),
                MerchantTextUtil.villagerLevel(entity),
                MerchantTextUtil.villagerLevelNumber(entity),
                MerchantTextUtil.villagerXp(entity),
                MerchantTextUtil.nextVillagerLevelXp(entity),
                WorldKeyUtil.dimensionKey(entity.method_73183()),
                entity.method_23317(),
                entity.method_23318(),
                entity.method_23321(),
                System.currentTimeMillis()
        );
    }

    public static PendingMerchantInteraction takeFresh() {
        long now = System.currentTimeMillis();
        if (pending == null || pending.expired(now, TradeCompassConfig.PENDING_INTERACTION_TTL_MILLIS)) {
            pending = null;
            return null;
        }
        PendingMerchantInteraction value = pending;
        pending = null;
        return value;
    }
}
