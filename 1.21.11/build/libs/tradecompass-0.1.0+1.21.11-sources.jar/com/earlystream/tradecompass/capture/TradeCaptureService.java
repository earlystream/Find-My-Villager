package com.earlystream.tradecompass.capture;

import com.earlystream.tradecompass.TradeCompassClient;
import com.earlystream.tradecompass.data.ItemStackRecord;
import com.earlystream.tradecompass.data.MerchantRecord;
import com.earlystream.tradecompass.data.TradeOfferRecord;
import com.earlystream.tradecompass.util.EnchantmentTextUtil;
import com.earlystream.tradecompass.util.ItemTextUtil;
import com.earlystream.tradecompass.util.WorldKeyUtil;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1728;
import net.minecraft.class_1914;
import net.minecraft.class_1916;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3850;
import net.minecraft.class_492;

public final class TradeCaptureService {
    private static int lastCapturedMenu = -1;
    private static int lastCapturedOfferCount = -1;
    private static int lastCapturedOfferSignature = 0;

    private TradeCaptureService() {
    }

    public static void tick(class_310 client) {
        if (!(client.field_1755 instanceof class_492 merchantScreen)) {
            lastCapturedMenu = -1;
            lastCapturedOfferCount = -1;
            lastCapturedOfferSignature = 0;
            return;
        }
        class_1728 menu = merchantScreen.method_17577();
        class_1916 offers = menu.method_17438();
        captureMenu(client, menu, offers);
    }

    public static void captureMenu(class_310 client, class_1728 menu, class_1916 offers) {
        if (client == null || menu == null) {
            return;
        }
        int menuIdentity = System.identityHashCode(menu);
        int offerCount = offers == null ? 0 : offers.size();
        int offerSignature = offerSignature(offers);
        if (offerCount <= 0 || (menuIdentity == lastCapturedMenu && offerCount == lastCapturedOfferCount && offerSignature == lastCapturedOfferSignature)) {
            return;
        }
        lastCapturedMenu = menuIdentity;
        lastCapturedOfferCount = offerCount;
        lastCapturedOfferSignature = offerSignature;
        capture(client, menu, offers);
    }

    private static void capture(class_310 client, class_1728 menu, class_1916 offers) {
        PendingMerchantInteraction pending = MerchantInteractionTracker.takeFresh();
        String worldKey = TradeCompassClient.loadedWorldKey();
        if (worldKey.isBlank()) {
            TradeCompassClient.ensureWorldLoaded(client);
            worldKey = TradeCompassClient.loadedWorldKey();
        }
        if (worldKey.isBlank()) {
            worldKey = WorldKeyUtil.currentWorldKey(client);
        }
        MerchantRecord record = new MerchantRecord();
        record.worldKey(worldKey);
        record.lastScannedEpochMillis(System.currentTimeMillis());
        if (pending == null) {
            record.merchantKey("unknown-" + record.lastScannedEpochMillis());
            record.entityType("Unknown merchant");
            record.profession("Unknown");
            record.dimension(WorldKeyUtil.currentDimension(client));
            record.unknownPosition(true);
        } else {
            record.merchantKey(pending.merchantKey(worldKey));
            record.entityUuid(pending.entityUuid());
            record.entityTypeId(pending.entityTypeId());
            record.entityType(pending.entityType());
            record.professionId(pending.professionId());
            record.profession(pending.profession());
            record.level(pending.level());
            record.levelNumber(pending.levelNumber());
            record.villagerXp(pending.villagerXp());
            record.nextLevelXp(pending.nextLevelXp());
            record.dimension(pending.dimension());
            record.x(pending.x());
            record.y(pending.y());
            record.z(pending.z());
            record.unknownPosition(false);
        }
        applyMenuLevelData(record, menu);
        List<TradeOfferRecord> capturedOffers = new ArrayList<>();
        for (class_1914 offer : offers) {
            capturedOffers.add(captureOffer(offer));
        }
        record.offers(capturedOffers);
        TradeCompassClient.upsert(record);
        if (client.field_1705 != null) {
            client.field_1705.method_1758(class_2561.method_43470(
                    "Trade Compass saved " + capturedOffers.size() + " trades for " + record.professionLevelText()
            ), false);
        }
    }

    private static int offerSignature(class_1916 offers) {
        if (offers == null || offers.isEmpty()) {
            return 0;
        }
        int signature = 1;
        for (class_1914 offer : offers) {
            signature = 31 * signature + ItemTextUtil.fromStack(offer.method_19272()).hashCode();
            signature = 31 * signature + ItemTextUtil.fromStack(offer.method_8247()).hashCode();
            signature = 31 * signature + ItemTextUtil.fromStack(offer.method_8250()).hashCode();
            signature = 31 * signature + offer.method_8249();
            signature = 31 * signature + offer.method_8248();
            signature = 31 * signature + offer.method_19277();
            signature = 31 * signature + (offer.method_8255() ? 1 : 0);
        }
        return signature;
    }

    private static void applyMenuLevelData(MerchantRecord record, class_1728 menu) {
        int level = menu.method_19258();
        if (level >= 1 && level <= 5) {
            record.levelNumber(level);
            record.level(levelName(level));
            if (menu.method_19259() && level < 5) {
                record.villagerXp(menu.method_19254());
                record.nextLevelXp(class_3850.method_19195(level));
            } else {
                record.villagerXp(0);
                record.nextLevelXp(-1);
            }
        }
    }

    private static String levelName(int level) {
        return switch (level) {
            case 1 -> "Novice";
            case 2 -> "Apprentice";
            case 3 -> "Journeyman";
            case 4 -> "Expert";
            case 5 -> "Master";
            default -> "";
        };
    }

    private static TradeOfferRecord captureOffer(class_1914 offer) {
        TradeOfferRecord record = new TradeOfferRecord();
        ItemStackRecord inputOne = ItemTextUtil.fromStack(offer.method_19272());
        record.inputOne(inputOne);
        record.inputTwo(ItemTextUtil.fromStack(offer.method_8247()));
        record.output(ItemTextUtil.fromStack(offer.method_8250()));
        record.outputEnchantments(EnchantmentTextUtil.fromStack(offer.method_8250()));
        record.currentPrice(inputOne.count());
        record.basePrice(ItemTextUtil.fromStack(offer.method_8246()).count());
        record.disabled(offer.method_8255());
        record.uses(offer.method_8249());
        record.maxUses(offer.method_8248());
        record.specialPrice(offer.method_19277());
        return record;
    }
}
