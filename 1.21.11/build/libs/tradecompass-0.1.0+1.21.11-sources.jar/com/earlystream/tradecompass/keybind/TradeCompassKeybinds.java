package com.earlystream.tradecompass.keybind;

import com.earlystream.tradecompass.config.TradeCompassConfig;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public final class TradeCompassKeybinds {
    private static class_304 openKey;
    private static final class_304.class_11900 CATEGORY = class_304.class_11900.method_74698(
            class_2960.method_60655(TradeCompassConfig.MOD_ID, "category")
    );

    private TradeCompassKeybinds() {
    }

    public static void register() {
        openKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.tradecompass.open",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_V,
                CATEGORY
        ));
    }

    public static class_304 openKey() {
        return openKey;
    }
}
