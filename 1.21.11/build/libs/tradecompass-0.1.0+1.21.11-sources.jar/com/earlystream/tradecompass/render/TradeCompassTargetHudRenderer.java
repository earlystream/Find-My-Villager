package com.earlystream.tradecompass.render;

import com.earlystream.tradecompass.TradeCompassClient;
import com.earlystream.tradecompass.config.TradeCompassConfig;
import com.earlystream.tradecompass.data.MerchantRecord;
import com.earlystream.tradecompass.data.SearchResult;
import com.earlystream.tradecompass.util.WorldKeyUtil;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3988;
import net.minecraft.class_9779;

public final class TradeCompassTargetHudRenderer {
    private static final float ARROW_SCALE = 1.875F;

    private TradeCompassTargetHudRenderer() {
    }

    public static void register() {
        HudElementRegistry.attachElementBefore(
                VanillaHudElements.OVERLAY_MESSAGE,
                class_2960.method_60655(TradeCompassConfig.MOD_ID, "target_arrow"),
                TradeCompassTargetHudRenderer::render
        );
    }

    private static void render(class_332 graphics, class_9779 deltaTracker) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) {
            return;
        }
        SearchResult selected = TradeCompassClient.selectedResult();
        if (selected == null) {
            return;
        }
        MerchantRecord merchant = selected.merchant();
        if (merchant == null || merchant.unknownPosition() || !WorldKeyUtil.currentDimension(client).equals(merchant.dimension())) {
            return;
        }
        class_3988 villager = TradeCompassWorldRenderer.targetVillager(client, selected);
        double targetX = villager == null ? merchant.x() : villager.method_23317();
        double targetZ = villager == null ? merchant.z() : villager.method_23321();
        double dx = targetX - client.field_1724.method_23317();
        double dz = targetZ - client.field_1724.method_23321();
        String arrow = directionArrow(client.field_1724.method_36454(), dx, dz);
        int x = Math.round((client.method_22683().method_4486() - client.field_1772.method_1727(arrow) * ARROW_SCALE) / 2.0F);
        int y = client.method_22683().method_4502() - 90;
        graphics.method_51448().pushMatrix();
        try {
            graphics.method_51448().translate(x, y);
            graphics.method_51448().scale(ARROW_SCALE);
            graphics.method_51433(client.field_1772, arrow, 0, 0, 0xFFFFE066, true);
        } finally {
            graphics.method_51448().popMatrix();
        }
    }

    private static String directionArrow(float playerYaw, double dx, double dz) {
        double yaw = Math.toRadians(playerYaw);
        double forward = dx * -Math.sin(yaw) + dz * Math.cos(yaw);
        double right = dx * -Math.cos(yaw) + dz * -Math.sin(yaw);
        if (Math.abs(right) > Math.abs(forward)) {
            return right > 0.0D ? "➡" : "⬅";
        }
        return forward > 0.0D ? "⬆" : "⬇";
    }
}
