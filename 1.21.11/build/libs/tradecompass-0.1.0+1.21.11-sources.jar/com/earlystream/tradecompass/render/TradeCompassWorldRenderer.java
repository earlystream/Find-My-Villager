package com.earlystream.tradecompass.render;

import com.earlystream.tradecompass.data.MerchantRecord;
import com.earlystream.tradecompass.data.SearchResult;
import com.earlystream.tradecompass.mixin.EntityGlowAccessor;
import com.earlystream.tradecompass.util.WorldKeyUtil;
import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import net.minecraft.class_3988;
import net.minecraft.class_638;

public final class TradeCompassWorldRenderer {
    private static UUID highlightedUuid;
    private static class_1297 highlightedEntity;
    private static boolean highlightedEntityWasGlowing;

    private TradeCompassWorldRenderer() {
    }

    public static void tick(class_310 client, SearchResult selectedResult) {
        class_3988 target = targetVillager(client, selectedResult);
        if (target == highlightedEntity) {
            if (target != null) {
                applyHighlight(target);
            }
            return;
        }
        clearHighlight();
        if (target == null) {
            return;
        }
        highlightedUuid = target.method_5667();
        highlightedEntity = target;
        highlightedEntityWasGlowing = target.method_5851();
        applyHighlight(target);
    }

    public static class_3988 targetVillager(class_310 client, SearchResult selectedResult) {
        if (selectedResult == null || client == null || client.field_1687 == null) {
            return null;
        }
        MerchantRecord merchant = selectedResult.merchant();
        if (merchant == null || merchant.entityUuid().isBlank()) {
            return null;
        }
        if (!WorldKeyUtil.currentDimension(client).equals(merchant.dimension())) {
            return null;
        }
        class_638 level = client.field_1687;
        UUID uuid;
        try {
            uuid = UUID.fromString(merchant.entityUuid());
        } catch (IllegalArgumentException exception) {
            return null;
        }
        class_1297 loadedEntity = level.method_66347(uuid);
        if (loadedEntity instanceof class_3988 villager) {
            return villager;
        }
        for (class_1297 entity : level.method_18112()) {
            if (uuid.equals(entity.method_5667()) && entity instanceof class_3988 villager) {
                return villager;
            }
        }
        return null;
    }

    private static void clearHighlight() {
        if (highlightedEntity != null && highlightedEntity.method_5805()
                && highlightedUuid != null && highlightedUuid.equals(highlightedEntity.method_5667())) {
            ((EntityGlowAccessor) highlightedEntity).tradecompass$setSharedFlag(6, highlightedEntityWasGlowing);
        }
        highlightedUuid = null;
        highlightedEntity = null;
        highlightedEntityWasGlowing = false;
    }

    private static void applyHighlight(class_1297 entity) {
        ((EntityGlowAccessor) entity).tradecompass$setSharedFlag(6, true);
    }
}
