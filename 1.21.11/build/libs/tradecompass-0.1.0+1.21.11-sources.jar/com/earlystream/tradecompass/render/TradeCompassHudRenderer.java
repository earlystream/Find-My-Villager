package com.earlystream.tradecompass.render;

import com.earlystream.tradecompass.data.MerchantRecord;
import com.earlystream.tradecompass.data.SearchResult;
import com.earlystream.tradecompass.util.WorldKeyUtil;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3988;

public final class TradeCompassHudRenderer {
    private static int cooldownTicks;

    private TradeCompassHudRenderer() {
    }

    public static void tick(class_310 client, SearchResult selectedResult) {
        if (selectedResult == null || client.field_1724 == null || client.field_1687 == null) {
            cooldownTicks = 0;
            return;
        }
        if (cooldownTicks++ % 20 != 0) {
            return;
        }
        MerchantRecord merchant = selectedResult.merchant();
        String text;
        if (merchant.unknownPosition()) {
            text = "Find My Villager: unknown merchant position";
        } else if (!WorldKeyUtil.currentDimension(client).equals(merchant.dimension())) {
            text = "Find My Villager: " + selectedResult.offer().output().name() + " is in a different dimension";
        } else {
            class_3988 villager = TradeCompassWorldRenderer.targetVillager(client, selectedResult);
            double targetX = villager == null ? merchant.x() : villager.method_23317();
            double targetZ = villager == null ? merchant.z() : villager.method_23321();
            double dx = targetX - client.field_1724.method_23317();
            double dz = targetZ - client.field_1724.method_23321();
            double distance = Math.sqrt(dx * dx + dz * dz);
            text = "Find My Villager: " + selectedResult.offer().output().name() + " - " + Math.round(distance) + "m, " + direction(dx, dz);
        }
        client.field_1705.method_1758(class_2561.method_43470(text), false);
    }

    private static String direction(double dx, double dz) {
        if (Math.abs(dx) > Math.abs(dz)) {
            return dx > 0 ? "east" : "west";
        }
        return dz > 0 ? "south" : "north";
    }
}
