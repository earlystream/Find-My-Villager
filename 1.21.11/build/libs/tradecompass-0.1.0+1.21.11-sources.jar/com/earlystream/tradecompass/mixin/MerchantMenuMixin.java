package com.earlystream.tradecompass.mixin;

import com.earlystream.tradecompass.capture.TradeCaptureService;
import net.minecraft.class_1728;
import net.minecraft.class_1916;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1728.class)
public abstract class MerchantMenuMixin {
    @Inject(method = "setOffers", at = @At("TAIL"))
    private void tradecompass$captureOffers(class_1916 offers, CallbackInfo ci) {
        TradeCaptureService.captureMenu(class_310.method_1551(), (class_1728) (Object) this, offers);
    }
}
