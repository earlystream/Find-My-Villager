package com.earlystream.tradecompass.mixin;

import net.minecraft.class_1297;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_1297.class)
public interface EntityGlowAccessor {
    @Invoker("setSharedFlag")
    void tradecompass$setSharedFlag(int flagIndex, boolean value);
}
