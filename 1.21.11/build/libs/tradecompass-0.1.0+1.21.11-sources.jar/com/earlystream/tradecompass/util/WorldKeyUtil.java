package com.earlystream.tradecompass.util;

import java.util.Locale;
import net.minecraft.class_1937;
import net.minecraft.class_310;
import net.minecraft.class_5321;
import net.minecraft.class_642;

public final class WorldKeyUtil {
    private WorldKeyUtil() {
    }

    public static String currentWorldKey(class_310 client) {
        if (client == null || client.field_1687 == null) {
            return "";
        }
        String dimension = currentDimension(client);
        class_642 serverData = client.method_1558();
        if (serverData != null) {
            return SafeFileNameUtil.safeKey("server", "server:" + serverData.field_3761 + ":" + dimension);
        }
        String singleplayerName = "singleplayer";
        if (client.method_1576() != null) {
            singleplayerName = client.method_1576().method_27728().method_150();
        }
        return SafeFileNameUtil.safeKey("singleplayer", "singleplayer:" + singleplayerName + ":" + dimension);
    }

    public static String currentDimension(class_310 client) {
        if (client == null || client.field_1687 == null) {
            return "";
        }
        return dimensionKey(client.field_1687);
    }

    public static String dimensionKey(class_1937 level) {
        if (level == null) {
            return "";
        }
        class_5321<class_1937> key = level.method_27983();
        return key.method_29177().toString().toLowerCase(Locale.ROOT);
    }
}
