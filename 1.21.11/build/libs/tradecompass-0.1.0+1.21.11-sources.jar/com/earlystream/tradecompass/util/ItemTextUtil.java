package com.earlystream.tradecompass.util;

import com.earlystream.tradecompass.data.ItemStackRecord;
import net.minecraft.class_1799;
import net.minecraft.class_7923;

public final class ItemTextUtil {
    private ItemTextUtil() {
    }

    public static ItemStackRecord fromStack(class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            return ItemStackRecord.empty();
        }
        String id = class_7923.field_41178.method_10221(stack.method_7909()).toString();
        String name = stack.method_7964().getString();
        return new ItemStackRecord(id, name, stack.method_7947());
    }
}
