package com.earlystream.tradecompass.util;

import java.util.Locale;
import net.minecraft.class_1297;
import net.minecraft.class_1646;
import net.minecraft.class_3850;
import net.minecraft.class_3852;
import net.minecraft.class_7923;

public final class MerchantTextUtil {
    private static final String[] LEVELS = {"", "Novice", "Apprentice", "Journeyman", "Expert", "Master"};

    private MerchantTextUtil() {
    }

    public static String entityTypeName(class_1297 entity) {
        if (entity == null) {
            return "Unknown merchant";
        }
        return title(class_7923.field_41177.method_10221(entity.method_5864()).method_12832());
    }

    public static String entityTypeId(class_1297 entity) {
        if (entity == null) {
            return "";
        }
        return class_7923.field_41177.method_10221(entity.method_5864()).toString();
    }

    public static String professionId(class_1297 entity) {
        if (entity instanceof class_1646 villager) {
            class_3852 profession = villager.method_7231().comp_3521().comp_349();
            return class_7923.field_41195.method_10221(profession).toString();
        }
        return "";
    }

    public static String professionName(class_1297 entity) {
        if (entity instanceof class_1646 villager) {
            class_3852 profession = villager.method_7231().comp_3521().comp_349();
            return title(class_7923.field_41195.method_10221(profession).method_12832());
        }
        return entityTypeName(entity);
    }

    public static String villagerLevel(class_1297 entity) {
        if (entity instanceof class_1646 villager) {
            class_3850 data = villager.method_7231();
            int level = data.comp_3522();
            if (level >= 1 && level < LEVELS.length) {
                return LEVELS[level];
            }
        }
        return "";
    }

    public static int villagerLevelNumber(class_1297 entity) {
        if (entity instanceof class_1646 villager) {
            return villager.method_7231().comp_3522();
        }
        return 0;
    }

    public static int villagerXp(class_1297 entity) {
        if (entity instanceof class_1646 villager) {
            return villager.method_19269();
        }
        return 0;
    }

    public static int nextVillagerLevelXp(class_1297 entity) {
        if (entity instanceof class_1646 villager) {
            int level = villager.method_7231().comp_3522();
            if (level >= 5) {
                return -1;
            }
            return class_3850.method_19195(level);
        }
        return -1;
    }

    private static String title(String value) {
        if (value == null || value.isBlank()) {
            return "Unknown";
        }
        String[] parts = value.replace('_', ' ').split(" ");
        StringBuilder builder = new StringBuilder();
        for (String part : parts) {
            if (part.isBlank()) {
                continue;
            }
            if (!builder.isEmpty()) {
                builder.append(' ');
            }
            builder.append(part.substring(0, 1).toUpperCase(Locale.ROOT));
            if (part.length() > 1) {
                builder.append(part.substring(1));
            }
        }
        return builder.toString();
    }
}
