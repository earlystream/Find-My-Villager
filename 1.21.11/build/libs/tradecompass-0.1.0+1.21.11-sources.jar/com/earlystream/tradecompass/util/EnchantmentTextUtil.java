package com.earlystream.tradecompass.util;

import it.unimi.dsi.fastutil.objects.Object2IntMap;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_6880;
import net.minecraft.class_9304;
import net.minecraft.class_9334;

public final class EnchantmentTextUtil {
    private EnchantmentTextUtil() {
    }

    public static List<String> fromStack(class_1799 stack) {
        List<String> enchantments = new ArrayList<>();
        if (stack == null || stack.method_7960()) {
            return enchantments;
        }
        addEnchantments(enchantments, stack.method_58695(class_9334.field_49633, class_9304.field_49385));
        addEnchantments(enchantments, stack.method_58695(class_9334.field_49643, class_9304.field_49385));
        return enchantments;
    }

    private static void addEnchantments(List<String> output, class_9304 enchantments) {
        for (Object2IntMap.Entry<class_6880<class_1887>> entry : enchantments.method_57539()) {
            String name = entry.getKey().comp_349().comp_2686().getString();
            int level = entry.getIntValue();
            output.add(name + " " + roman(level));
        }
    }

    private static String roman(int value) {
        return switch (value) {
            case 1 -> "I";
            case 2 -> "II";
            case 3 -> "III";
            case 4 -> "IV";
            case 5 -> "V";
            default -> Integer.toString(value);
        };
    }
}
